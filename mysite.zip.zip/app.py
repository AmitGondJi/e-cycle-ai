from flask import Flask, render_template, request, redirect, session, url_for, send_file
import sqlite3
import os
import io
from fpdf import FPDF  # PDF Library
from werkzeug.utils import secure_filename # NEW: Image handle karne ke liye
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'amit_project_key'

# --- 1. SERVER PATH CONFIGURATION (IMPORTANT FOR PYTHONANYWHERE) ---
# Ye line batayegi ki project server par kahan rakha hai
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, 'database.db')
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'static/uploads')

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Agar folder nahi hai to khud bana dega
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# --- DATABASE CONNECTION ---
def get_db_connection():
    conn = sqlite3.connect(DB_PATH) # Updated path
    conn.row_factory = sqlite3.Row
    return conn

# --- INITIALIZE DATABASE ---
def init_db():
    if not os.path.exists(DB_PATH): # Updated path
        conn = sqlite3.connect(DB_PATH) # Updated path
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS users 
                     (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT, points INTEGER DEFAULT 0)''')
        c.execute('''CREATE TABLE IF NOT EXISTS requests 
                     (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, 
                      item_name TEXT, quantity INTEGER, address TEXT, status TEXT)''')
        conn.commit()
        conn.close()
        print("Database Ready!")

init_db()

# --- MOCK AI FUNCTION (NEW) ---
# Ye function AI hone ka naatak karega based on filename
def ai_smart_detect(filename):
    filename = filename.lower()
    if 'laptop' in filename:
        return "Laptop (Detected via AI)"
    elif 'phone' in filename or 'mobile' in filename:
        return "Mobile Phone (Detected via AI)"
    elif 'keyboard' in filename:
        return "Keyboard (Detected via AI)"
    elif 'mouse' in filename:
        return "Mouse (Detected via AI)"
    else:
        return "Electronic Gadget (Unknown Type)"

# --- ROUTES ---

@app.route('/')
def home():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE username = ? AND password = ?', (username, password)).fetchone()
        conn.close()
        
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            return redirect(url_for('dashboard'))
        else:
            return "Galat Username ya Password! <a href='/login'>Try Again</a>"
            
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = get_db_connection()
        conn.execute('INSERT INTO users (username, password, points) VALUES (?, ?, 0)', (username, password))
        conn.commit()
        conn.close()
        return redirect(url_for('login'))
    return render_template('register.html')

# --- UPDATED DASHBOARD WITH LEADERBOARD ---
@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session: return redirect(url_for('login'))
    
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
    reqs = conn.execute('SELECT * FROM requests WHERE user_id = ?', (session['user_id'],)).fetchall()
    
    # --- NEW: Fetch Top 3 Users for Leaderboard ---
    leaderboard = conn.execute('SELECT username, points FROM users ORDER BY points DESC LIMIT 3').fetchall()
    
    conn.close()

    # Agar DB reset hua aur user nahi mila, toh logout
    if user is None:
        session.clear()
        return redirect(url_for('login'))
    
    # Leaderboard variable bhi pass kar rahe hain
    return render_template('dashboard.html', 
                           requests=reqs, 
                           name=session['username'], 
                           points=user['points'], 
                           leaderboard=leaderboard)

# --- UPDATED ADD_REQUEST (AI ENABLED) ---
@app.route('/add_request', methods=['GET', 'POST'])
def add_request():
    if 'user_id' not in session: return redirect(url_for('login'))
    
    if request.method == 'POST':
        # 1. IMAGE CHECK KARO
        if 'file' not in request.files:
            return 'No file part'
        
        file = request.files['file']
        
        if file.filename == '':
            return 'No selected file'

        if file:
            # 2. FILE SAVE KARO
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            
            # 3. AI SE POOCHO YE KYA HAI (PREDICTION)
            detected_item_name = ai_smart_detect(filename)
            
            # 4. BAKI DATA LO
            qty = request.form.get('quantity')
            addr = request.form.get('address')
            
            # 5. DATABASE ME SAVE KARO (Detected Name ke sath)
            conn = get_db_connection()
            conn.execute('INSERT INTO requests (user_id, item_name, quantity, address, status) VALUES (?, ?, ?, ?, ?)',
                         (session['user_id'], detected_item_name, qty, addr, 'Pending'))
            conn.commit()
            conn.close()
            return redirect(url_for('dashboard'))
        
    return render_template('add_request.html')

# --- ADMIN PANEL ---

@app.route('/admin')
def admin_panel():
    conn = get_db_connection()
    all_requests = conn.execute('''
        SELECT requests.*, users.username 
        FROM requests 
        JOIN users ON requests.user_id = users.id
    ''').fetchall()
    conn.close()
    return render_template('admin.html', requests=all_requests)

@app.route('/update_status/<int:req_id>/<string:new_status>')
def update_status(req_id, new_status):
    conn = get_db_connection()
    req = conn.execute('SELECT * FROM requests WHERE id = ?', (req_id,)).fetchone()
    
    if new_status == 'Recycled' and req['status'] != 'Recycled':
        item_name = req['item_name'].lower()
        points_to_add = 10 
        if 'laptop' in item_name: points_to_add = 50
        elif 'phone' in item_name or 'mobile' in item_name: points_to_add = 30
        
        conn.execute('UPDATE users SET points = points + ? WHERE id = ?', (points_to_add, req['user_id']))

    conn.execute('UPDATE requests SET status = ? WHERE id = ?', (new_status, req_id))
    conn.commit()
    conn.close()
    return redirect(url_for('admin_panel'))

# --- CERTIFICATE GENERATION CODE ---
@app.route('/download_certificate/<int:req_id>')
def download_certificate(req_id):
    if 'user_id' not in session: return redirect(url_for('login'))
    
    conn = get_db_connection()
    data = conn.execute('''
        SELECT requests.*, users.username 
        FROM requests 
        JOIN users ON requests.user_id = users.id 
        WHERE requests.id = ?
    ''', (req_id,)).fetchone()
    conn.close()
    
    if not data or data['status'] != 'Recycled':
        return "Certificate not available yet!"

    # --- PDF GENERATION STARTS ---
    pdf = FPDF(orientation='L', unit='mm', format='A4') # Landscape mode (Zayada acha lagta hai)
    pdf.add_page()
    
    # 1. DOUBLE BORDER (Decorative)
    pdf.set_line_width(2)
    pdf.set_draw_color(46, 125, 50) # Dark Green
    pdf.rect(10, 10, 277, 190) # Outer Border
    
    pdf.set_line_width(0.5)
    pdf.rect(15, 15, 267, 180) # Inner Border

    # 2. HEADER LOGO
    # Note: Server par internet access chahiye logo ke liye
    try:
        pdf.image('https://cdn-icons-png.flaticon.com/512/1598/1598196.png', x=135, y=20, w=25) 
        pdf.ln(35) # Space after logo
    except:
        pdf.ln(20) # Agar logo load na ho to bas space de do

    # 3. TITLE
    pdf.set_font("Arial", 'B', 36)
    pdf.set_text_color(46, 125, 50)
    pdf.cell(0, 10, "CERTIFICATE OF RECYCLING", ln=True, align='C')
    
    pdf.set_font("Arial", 'I', 14)
    pdf.set_text_color(100, 100, 100) # Grey Color
    pdf.cell(0, 15, "This certifies that", ln=True, align='C')
    
    pdf.ln(5)

    # 4. USER NAME (Hero of the certificate)
    pdf.set_font("Times", 'B', 40) # Times font looks majestic
    pdf.set_text_color(0, 0, 0)
    pdf.cell(0, 20, data['username'].upper(), ln=True, align='C')
    
    pdf.set_line_width(1)
    pdf.set_draw_color(150, 150, 150)
    pdf.line(70, 95, 227, 95) # Underline name

    pdf.ln(10)

    # 5. BODY TEXT
    pdf.set_font("Arial", size=16)
    pdf.set_text_color(50, 50, 50)
    body_text = (f"Has successfully recycled e-waste through the e-Cycle AI Platform. "
                 f"Their contribution has helped prevent hazardous materials from entering landfills. "
                 f"\n\nRecycled Item: {data['item_name']}  |  Quantity: {data['quantity']}")
    pdf.multi_cell(0, 10, body_text, align='C')

    pdf.ln(25)

    # 6. FOOTER (Date & Signature)
    pdf.set_y(-50) # Bottom se thoda upar
    
    # Date Left Side
    current_date = datetime.now().strftime("%d %B, %Y")
    pdf.set_font("Arial", 'B', 12)
    pdf.cell(90, 10, f"Date: {current_date}", align='C')
    
    # Signature Right Side
    pdf.cell(90, 10, "", align='C') # Empty space beech me
    pdf.cell(90, 10, "Authorized Signatory", align='C')

    # Signature Line
    pdf.line(200, 173, 270, 173) 

    # 7. WATERMARK (Optional Footer Text)
    pdf.set_y(-20)
    pdf.set_font("Arial", 'I', 10)
    pdf.set_text_color(150, 150, 150)
    pdf.cell(0, 10, "Verified by e-Cycle AI Green Technology Initiative", align='C')

    # Output
    pdf_output = pdf.output(dest='S').encode('latin-1')
    return send_file(io.BytesIO(pdf_output), mimetype='application/pdf', as_attachment=True, download_name='Green_Certificate_Pro.pdf')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)